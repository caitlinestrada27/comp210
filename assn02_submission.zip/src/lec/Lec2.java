package lec;

public class Lec2 {

    public static void main (String[] args){
        int n = 0;
        m1();
    }

    public static void m1 (){
        int n1 = 1;
    }
}
